import { useState, useCallback } from "react";
import { Sidebar }       from "./components/Sidebar/Sidebar";
import { Canvas }        from "./components/Canvas/Canvas";
import { Terminal }      from "./components/Terminal/Terminal";
import { RouterCLI }     from "./components/RouterCLI/RouterCLI";
import { useBoardStore } from "./store/useBoardStore";
import { usePing }       from "./hooks/usePing";
import { useTerminal }   from "./hooks/useTerminal";
import "./styles/global.css";

export default function NetworkingBoard() {
  const {
    devices, links, leds,
    addDevice, updateDevice, updateInterface,
    removeDevice, moveDevice,
    addLink, removeLink,
    setLed,
  } = useBoardStore();

  const { logs, addLog, clear: clearLogs, termRef } = useTerminal();
  const { running, packet, run } = usePing({ devices, onLed: setLed });
  const [cliOpen, setCliOpen] = useState(null);

  const handleDevicePress = useCallback(id => {
    if (id.startsWith("__delete__")) { removeDevice(id.replace("__delete__","")); return; }
    setCliOpen(id);
  }, [removeDevice]);

  // updateDevice enrichi : gère aussi les patches d'interfaces
  const handleUpdate = useCallback((id, patch) => {
    if (patch.interfaces) {
      // patch direct du tableau d'interfaces (depuis config-if)
      updateDevice(id, { interfaces: patch.interfaces });
    } else {
      updateDevice(id, patch);
    }
  }, [updateDevice]);

  const handleCliPing = useCallback(({ srcId, dstIp, count, ttl, onLog }) => {
    run({ srcId, dstIp, count, ttl, onLog });
  }, [run]);

  const dc = Object.keys(devices).length;
  const lc = Object.keys(links).length;
  const oc = Object.values(devices).filter(d => d.status === "online").length;

  return (
    <div className="app">
      <header className="app__topbar">
        <div className="app__topbar-dot"/>
        <span className="app__topbar-title">Networking Board</span>
        <span className="app__topbar-sep">|</span>
        <span style={{ fontSize:10, color:"#2a4a60", fontFamily:"JetBrains Mono,monospace" }}>
          Simulation ICMP · Multi-interface
        </span>
        <div className="app__topbar-right">
          <span className="app__topbar-badge">{dc} devices</span>
          <span className="app__topbar-badge">{lc} liens</span>
          <span className="app__topbar-badge" style={{ color: oc===dc&&dc>0?"#1D9E75":"#3a5060" }}>
            {oc}/{dc} online
          </span>
        </div>
      </header>

      <div className="app__body">
        <Sidebar devices={devices} onDevicePress={handleDevicePress}/>
        <div className="app__center">
          <Canvas
            devices={devices} links={links} leds={leds} packet={packet}
            onAddDevice={addDevice} onMoveDevice={moveDevice}
            onAddLink={addLink} onRemoveLink={removeLink}
            onDevicePress={handleDevicePress}
          />
          <div className="app__terminal">
            <div className="app__terminal-header">
              <span className="app__terminal-title">Terminal réseau</span>
              {running && (
                <span style={{ fontSize:9, color:"#378ADD", fontFamily:"JetBrains Mono,monospace", animation:"pulse 1s infinite" }}>
                  ● ping en cours
                </span>
              )}
              <button className="app__terminal-clear" onClick={clearLogs}>effacer</button>
            </div>
            <Terminal logs={logs} running={running} termRef={termRef}/>
          </div>
        </div>
      </div>

      {cliOpen && devices[cliOpen] && (
        <RouterCLI
          device={devices[cliOpen]}
          devices={devices}
          onUpdate={handleUpdate}
          onPing={handleCliPing}
          onClose={() => setCliOpen(null)}
        />
      )}

      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0}}`}</style>
    </div>
  );
}
